package za.ac.iie.flashcard

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {

    private val questions = arrayOf(
        "The Sharpeville Massacre occurred in 1960.",
        "The ANC was founded in 1994.",
        "Nelson Mandela served only one term as President of South Africa.",
        "The discovery of gold in Johannesburg happened in the 1800s.",
        "The Dutch were the first Europeans to settle in South Africa."
    )

    private val answers = arrayOf(true, false, true, true, true)
    private var questionsIndex = 0
    private var score = 0


    private lateinit var txtQuestion: TextView
    private lateinit var txtResult: TextView
    private lateinit var btnTrue: Button
    private lateinit var btnFalse: Button
    private lateinit var btnNext: Button


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)


        val txtQuestion = findViewById<TextView>(R.id.txtQuestion)
        val txtResult = findViewById<TextView>(R.id.txtResults)
        val btnTrue = findViewById<Button>(R.id.btnTrue)
        val btnFalse = findViewById<Button>(R.id.btnFalse)
        val btnNext = findViewById<Button>(R.id.btnNext)


        loadQuestion()


        btnFalse.setOnClickListener {
            checkAnswer(false)
        }


        btnTrue.setOnClickListener {
            checkAnswer(true)
        }
    }
        private fun loadQuestion() {
            txtQuestion.text = questions[questionsIndex]
            txtResult.text = ""
            btnFalse.isEnabled = true
            btnTrue.isEnabled = true
        }
        fun checkAnswer(userAnswer: Boolean) {
            if (userAnswer == answers[questionsIndex]) {
                score++
                txtResult.text = "Correct!"
            } else {
                txtResult.text = "Incorrect!"
            }
        }
    }













